(() => {
  const router = require("router");

  router.get("/", (req, res) => {
    res.render({});
  });
})();
